/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#6C63FF",
          light: "#8D86FF",
          dark: "#574FE0",
        },
        secondary: {
          DEFAULT: "#4F8BFF",
          light: "#76A9FF",
          dark: "#3B68CC",
        }
      }
    }
  },
  plugins: [],
}
