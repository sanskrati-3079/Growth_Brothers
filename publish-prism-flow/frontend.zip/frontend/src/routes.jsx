import React from "react";
import { createBrowserRouter } from "react-router-dom";
import App from "./App";
import Home from "./pages/Home";
import Upload from "./pages/Upload";
import AIStudio from "./pages/AIStudio";
import Scheduler from "./pages/Scheduler";
import Analytics from "./pages/Analytics";
import Engagement from "./pages/Engagement";
import Accounts from "./pages/Accounts";
import Admin from "./pages/Admin";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      { index: true, element: <Home /> },
      { path: "upload", element: <Upload /> },
      { path: "ai", element: <AIStudio /> },
      { path: "scheduler", element: <Scheduler /> },
      { path: "analytics", element: <Analytics /> },
      { path: "engagement", element: <Engagement /> },
      { path: "accounts", element: <Accounts /> },
      { path: "admin", element: <Admin /> },
    ],
  },
]);
