import React, { useState } from "react";
import ScheduleForm from "../components/scheduler/ScheduleForm";
import CalendarView from "../components/scheduler/CalendarView";

export default function Scheduler() {
  const [items, setItems] = useState([]);

  const onSchedule = (entry) => {
    setItems((prev) => [
      ...prev,
      { id: crypto.randomUUID(), title: "New Post", time: entry.when, platform: entry.platform },
    ]);
  };

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-primary/10">
        <h1 className="text-xl font-semibold text-primary-dark">Scheduler</h1>
        <p className="text-sm text-slate-600">Plan your content across platforms.</p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <ScheduleForm onSchedule={onSchedule} />
        <CalendarView items={items} />
      </div>
    </div>
  );
}
