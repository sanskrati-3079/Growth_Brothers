import React from "react";

export default function Admin() {
  const items = [
    { id: "log_001", message: "MCP tool publish_reel invoked", level: "info" },
    { id: "log_002", message: "Connector rate-limited, retry in 60s", level: "warn" },
  ];

  return (
    <div className="space-y-6">
      <div className="card">
        <h2 className="text-lg font-semibold text-primary-dark">System Logs</h2>
        <ul className="mt-3 space-y-2 text-sm">
          {items.map((i) => (
            <li key={i.id} className="rounded-xl border p-3 ring-1 ring-secondary/20">
              <span className="mr-2 inline-block rounded-full bg-primary/10 px-2 py-0.5 text-xs uppercase text-primary">
                {i.level}
              </span>
              <span>{i.message}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
