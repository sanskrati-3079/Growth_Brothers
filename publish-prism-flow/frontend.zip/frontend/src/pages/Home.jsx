import React from "react";

export default function Home() {
  const stats = [
    { label: "Total Uploads", value: 42 },
    { label: "Scheduled", value: 7 },
    { label: "Platforms", value: 3 },
    { label: "Engagement", value: "86%" },
  ];

  const upcoming = [
    { id: "sch_101", time: "Today 6:30 PM", platform: "Instagram", title: "Navbar in 60s" },
    { id: "sch_102", time: "Tomorrow 10:00 AM", platform: "YouTube", title: "Async patterns" },
  ];

  return (
    <div className="space-y-6">
      <header className="overflow-hidden rounded-2xl bg-gradient-to-r from-primary to-secondary p-6 shadow-sm ring-1 ring-primary/20">
        <h1 className="text-2xl font-semibold tracking-tight text-white">Welcome back 👋</h1>
        <p className="mt-1 text-sm text-white/90">
          Your distribution cockpit — upload, repurpose, schedule, and track.
        </p>
        <div className="mt-4 flex gap-2">
          <a href="/upload" className="btn btn-secondary bg-white text-primary hover:bg-slate-100">
            New Upload
          </a>
          <a href="/ai" className="btn btn-primary border border-white/30">
            Open AI Studio
          </a>
        </div>
      </header>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.label} className="card">
            <p className="text-sm text-secondary-dark">{s.label}</p>
            <p className="mt-2 text-3xl font-semibold text-primary">{s.value}</p>
          </div>
        ))}
      </section>

      <section className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="card lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="card-title">Recent Activity</h2>
            <a href="/upload" className="text-sm font-medium text-secondary hover:text-secondary-dark">
              View all
            </a>
          </div>
          <div className="mt-4 overflow-hidden rounded-xl border border-slate-200">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="table-head">
                <tr>
                  <th className="px-4 py-3">Title</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Status</th>
                  <th className="px-4 py-3">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                <tr className="hover:bg-primary/5">
                  <td className="px-4 py-3 text-sm">Designing a clean navbar</td>
                  <td className="px-4 py-3 text-sm">Reel</td>
                  <td className="px-4 py-3 text-sm text-secondary">Processing</td>
                  <td className="px-4 py-3 text-sm">2025-12-05 14:12</td>
                </tr>
                <tr className="hover:bg-primary/5">
                  <td className="px-4 py-3 text-sm">Async patterns you should know</td>
                  <td className="px-4 py-3 text-sm">Short</td>
                  <td className="px-4 py-3 text-sm text-primary">Ready to Schedule</td>
                  <td className="px-4 py-3 text-sm">2025-12-05 12:03</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <h2 className="card-title">Schedule Overview</h2>
          <ul className="mt-4 space-y-3">
            {upcoming.map((u) => (
              <li key={u.id} className="rounded-xl border border-slate-200 p-4 hover:bg-secondary/5">
                <p className="text-sm text-slate-500">{u.time} • {u.platform}</p>
                <p className="mt-1 font-medium text-primary-dark">{u.title}</p>
              </li>
            ))}
          </ul>
          <a href="/scheduler" className="btn btn-secondary mt-4">Open Scheduler →</a>
        </div>
      </section>
    </div>
  );
}
