import React, { useState } from "react";
import VideoUpload from "../components/upload/VideoUpload";
import MediaPreview from "../components/upload/MediaPreview";
import UploadStatus from "../components/upload/UploadStatus";

export default function Upload() {
  const [file, setFile] = useState(null);
  const [src, setSrc] = useState(null);
  const [progress, setProgress] = useState(0);

  const onSelect = (f) => {
    setFile(f);
    setSrc(URL.createObjectURL(f));
    setProgress(10);
    const id = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) { clearInterval(id); return 100; }
        return p + 10;
      });
    }, 200);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold text-primary-dark">Upload</h1>
        <a href="/ai" className="btn btn-secondary">Go to AI Studio</a>
      </div>
      <VideoUpload onSelect={onSelect} />
      <MediaPreview src={src} />
      <UploadStatus status={file ? "Uploading" : "Idle"} progress={progress} />
    </div>
  );
}
