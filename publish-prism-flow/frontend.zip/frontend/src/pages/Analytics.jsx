import React from "react";
import AnalyticsCharts from "../components/analytics/AnalyticsCharts";
import ABTestComparisons from "../components/analytics/ABTestComparisons";

export default function Analytics() {
  const data = { views: [10, 20, 35, 18], likes: [2, 5, 7, 4] };
  const variants = [
    { id: "A", variant: "A", caption: "Short hook", ctr: 3.4, reach: 1200 },
    { id: "B", variant: "B", caption: "Long value", ctr: 4.1, reach: 1370 },
  ];
  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-primary/10">
        <h1 className="text-xl font-semibold text-primary-dark">Analytics</h1>
        <p className="text-sm text-slate-600">Track performance & experiments.</p>
      </header>

      <div className="grid grid-cols-1 gap-6">
        <AnalyticsCharts data={data} />
        <ABTestComparisons variants={variants} />
      </div>
    </div>
  );
}
