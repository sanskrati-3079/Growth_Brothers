import React, { useState } from "react";
import CaptionGenerator from "../components/ai/CaptionGenerator";
import HashtagGenerator from "../components/ai/HashtagGenerator";
import TextPostGenerator from "../components/ai/TextPostGenerator";
import CarouselPreview from "../components/ai/CarouselPreview";

export default function AIStudio() {
  const [caption, setCaption] = useState("");
  const [tags, setTags] = useState("");
  const [post, setPost] = useState("");
  const [slides, setSlides] = useState(["Slide 1", "Slide 2", "Slide 3"]);

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-primary/10">
        <h1 className="text-xl font-semibold text-primary-dark">AI Studio</h1>
        <p className="text-sm text-slate-600">Generate captions, hashtags, carousels and posts.</p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <CaptionGenerator onGenerate={setCaption} />
        <HashtagGenerator onGenerate={setTags} />
        <TextPostGenerator platform="linkedin" onGenerate={setPost} />
        <CarouselPreview slides={slides} />

        <div className="card lg:col-span-2">
          <p className="card-title">Outputs</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-3 text-sm">
            <pre className="rounded-xl border p-3 ring-1 ring-primary/10">{caption || "No caption yet"}</pre>
            <pre className="rounded-xl border p-3 ring-1 ring-primary/10">{tags || "No hashtags yet"}</pre>
            <pre className="rounded-xl border p-3 ring-1 ring-primary/10">{post || "No post yet"}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
