import React from "react";

export default function Accounts() {
  const items = [
    { name: "Instagram", connected: true },
    { name: "YouTube", connected: true },
    { name: "TikTok", connected: false },
  ];

  return (
    <div className="card">
      <h2 className="text-lg font-semibold text-primary-dark">Connected Accounts</h2>
      <ul className="mt-4 divide-y">
        {items.map((p) => (
          <li key={p.name} className="flex items-center justify-between py-3">
            <span className="font-medium">{p.name}</span>
            {p.connected ? (
              <span className="text-sm text-emerald-600">Connected</span>
            ) : (
              <button className="btn btn-primary">Connect</button>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
