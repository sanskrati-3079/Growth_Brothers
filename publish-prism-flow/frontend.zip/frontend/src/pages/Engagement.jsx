import React, { useState } from "react";
import AutoReplies from "../components/engagement/AutoReplies";
import CommentCategorizer from "../components/engagement/CommentCategorizer";

export default function Engagement() {
  const [comments] = useState([
    { id: 1, user: "Neha", text: "Great video!", category: "Engagement" },
    { id: 2, user: "Ravi", text: "How did you build this?", category: "Growth" },
  ]);

  return (
    <div className="space-y-6">
      <header className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-primary/10">
        <h1 className="text-xl font-semibold text-primary-dark">Engagement</h1>
        <p className="text-sm text-slate-600">Manage comments and auto-replies.</p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <AutoReplies onSend={(msg) => alert(`Saved template: ${msg}`)} />
        <CommentCategorizer comments={comments} />
      </div>
    </div>
  );
}
