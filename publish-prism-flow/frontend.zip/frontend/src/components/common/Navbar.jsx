import React from "react";

export default function Navbar() {
  return (
    <header className="border-b bg-white">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <a href="/" className="font-semibold tracking-tight text-primary">
          Content Agent
        </a>
        <nav className="flex items-center gap-4 text-sm">
          <a className="hover:text-primary-dark" href="/upload">Upload</a>
          <a className="hover:text-primary-dark" href="/ai">AI Studio</a>
          <a className="hover:text-primary-dark" href="/scheduler">Scheduler</a>
          <a className="hover:text-primary-dark" href="/analytics">Analytics</a>
        </nav>
        <div className="hidden sm:flex items-center gap-2">
          <a href="/accounts" className="btn btn-secondary">Accounts</a>
          <a href="/admin" className="btn btn-primary">Admin</a>
        </div>
      </div>
    </header>
  );
}
