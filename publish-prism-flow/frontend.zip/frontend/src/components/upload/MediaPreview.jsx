import React from "react";

export default function MediaPreview({ src, title = "Preview" }) {
  if (!src) return null;
  return (
    <div className="card">
      <p className="text-sm font-medium text-primary-dark">{title}</p>
      <video src={src} controls className="mt-3 w-full rounded-xl ring-1 ring-primary/20" />
    </div>
  );
}
