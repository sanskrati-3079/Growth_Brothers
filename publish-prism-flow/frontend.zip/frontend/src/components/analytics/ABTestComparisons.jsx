import React from "react";

export default function ABTestComparisons({ variants = [] }) {
  return (
    <div className="card">
      <p className="card-title">A/B Tests</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {variants.length ? variants.map((v) => (
          <div key={v.id} className="rounded-xl border p-3 ring-1 ring-primary/20">
            <p className="text-sm font-semibold text-primary">Variant {v.variant}</p>
            <p className="mt-1 text-xs text-slate-500">Caption: {v.caption}</p>
            <p className="mt-1 text-xs">CTR: <span className="text-secondary font-medium">{v.ctr}%</span> • Reach: {v.reach}</p>
          </div>
        )) : <p className="text-sm text-slate-500">No experiments yet</p>}
      </div>
    </div>
  );
}
