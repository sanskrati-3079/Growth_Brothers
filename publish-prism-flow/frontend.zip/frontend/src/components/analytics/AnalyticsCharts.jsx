import React from "react";

export default function AnalyticsCharts({ data = { views: [], likes: [] } }) {
  const sections = Object.entries(data);
  return (
    <div className="card">
      <p className="card-title">Analytics (preview)</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        {sections.map(([k, vals]) => (
          <div key={k} className="rounded-xl border p-3 ring-1 ring-primary/20">
            <p className="text-sm font-medium capitalize text-secondary-dark">{k}</p>
            <p className="mt-1 text-xs text-slate-500">
              {vals.length ? vals.join(", ") : "No data"}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
