import React, { useState } from "react";

export default function ScheduleForm({ onSchedule }) {
  const [when, setWhen] = useState("");
  const [platform, setPlatform] = useState("instagram");

  const submit = (e) => {
    e.preventDefault();
    onSchedule?.({ when, platform });
  };

  return (
    <form onSubmit={submit} className="card">
      <p className="card-title">Schedule Post</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-2">
        <input
          type="datetime-local"
          className="input"
          value={when}
          onChange={(e) => setWhen(e.target.value)}
        />
        <select
          className="input"
          value={platform}
          onChange={(e) => setPlatform(e.target.value)}
        >
          <option value="instagram">Instagram</option>
          <option value="youtube">YouTube</option>
          <option value="tiktok">TikTok</option>
          <option value="twitter">X / Twitter</option>
          <option value="linkedin">LinkedIn</option>
        </select>
      </div>
      <button className="btn btn-primary mt-3">Add to Schedule</button>
    </form>
  );
}
