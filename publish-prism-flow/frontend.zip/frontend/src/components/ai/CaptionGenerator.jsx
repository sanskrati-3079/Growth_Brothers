import React, { useState } from "react";

export default function CaptionGenerator({ onGenerate }) {
  const [topic, setTopic] = useState("");

  const submit = (e) => {
    e.preventDefault();
    const caption = `Hook: ${topic}\nValue: ...\nCTA: Follow for more!`;
    onGenerate?.(caption);
  };

  return (
    <form onSubmit={submit} className="card">
      <p className="card-title">AI Caption Generator</p>
      <input
        className="input mt-3"
        placeholder="Topic or transcript snippet"
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
      />
      <button className="btn btn-primary mt-3">Generate</button>
    </form>
  );
}
