import React, { useState } from "react";

export default function HashtagGenerator({ onGenerate }) {
  const [keywords, setKeywords] = useState("");
  const submit = (e) => {
    e.preventDefault();
    const tags = ["#design", "#frontend", "#coding", "#react"].join(" ");
    onGenerate?.(tags);
  };
  return (
    <form onSubmit={submit} className="card">
      <p className="card-title">AI Hashtag Generator</p>
      <input
        className="input mt-3"
        placeholder="Keywords"
        value={keywords}
        onChange={(e) => setKeywords(e.target.value)}
      />
      <button className="btn btn-primary mt-3">Generate</button>
    </form>
  );
}
