import React from "react";

export default function CarouselPreview({ slides = [] }) {
  if (!slides.length) return null;
  return (
    <div className="card">
      <p className="card-title">Carousel Preview</p>
      <div className="mt-3 grid gap-3 sm:grid-cols-3">
        {slides.map((s, i) => (
          <div key={i} className="rounded-xl border p-4 text-sm ring-1 ring-secondary/20">
            {s}
          </div>
        ))}
      </div>
    </div>
  );
}
