import React, { useState } from "react";

export default function TextPostGenerator({ platform = "linkedin", onGenerate }) {
  const [text, setText] = useState("");
  const submit = (e) => {
    e.preventDefault();
    const post = `(${platform.toUpperCase()}) Hook → Value → CTA\n\n${text}`;
    onGenerate?.(post);
  };
  return (
    <form onSubmit={submit} className="card">
      <p className="card-title">Reel → {platform} Post</p>
      <textarea
        className="input mt-3 h-32"
        placeholder="Paste transcript..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button className="btn btn-secondary mt-3">Generate</button>
    </form>
  );
}
