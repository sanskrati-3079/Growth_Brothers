import React from "react";

export default function CommentCategorizer({ comments = [] }) {
  return (
    <div className="card">
      <p className="card-title">Comment Categories</p>
      <ul className="mt-3 space-y-2 text-sm">
        {comments.length ? comments.map((c) => (
          <li key={c.id} className="rounded-xl border p-3 ring-1 ring-secondary/20">
            <div className="font-medium text-primary">{c.user}</div>
            <div className="text-slate-700">{c.text}</div>
            <div className="mt-1 text-xs text-slate-500">Category: <span className="text-secondary-dark">{c.category}</span></div>
          </li>
        )) : <li className="text-slate-500">No comments</li>}
      </ul>
    </div>
  );
}
