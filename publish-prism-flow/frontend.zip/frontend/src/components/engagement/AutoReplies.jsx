import React, { useState } from "react";

export default function AutoReplies({ onSend }) {
  const [message, setMessage] = useState("Thanks for your comment!");
  return (
    <div className="card">
      <p className="card-title">Auto Replies</p>
      <textarea
        className="input mt-3 h-28"
        rows={3}
        value={message}
        onChange={(e) => setMessage(e.target.value)}
      />
      <button
        onClick={() => onSend?.(message)}
        className="btn btn-secondary mt-3"
      >
        Save Template
      </button>
    </div>
  );
}
