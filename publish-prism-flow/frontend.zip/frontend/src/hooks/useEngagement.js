import { useState } from "react";

export function useEngagement() {
  const [comments] = useState([
    { id: 1, user: "Neha", text: "Great video!", category: "Engagement" },
  ]);

  const saveTemplate = (message) => {
    return { ok: true, message };
  };

  return { comments, saveTemplate };
}
export default useEngagement;
