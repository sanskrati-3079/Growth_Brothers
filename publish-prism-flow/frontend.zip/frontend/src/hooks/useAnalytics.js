import { useEffect, useState } from "react";

export function useAnalytics() {
  const [data, setData] = useState({ views: [], likes: [] });

  useEffect(() => {
    setData({ views: [10, 20, 35, 18], likes: [2, 5, 7, 4] });
  }, []);

  return data;
}
export default useAnalytics;
