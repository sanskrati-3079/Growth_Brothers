import { useCallback, useState } from "react";

export function useAI() {
  const [loading, setLoading] = useState(false);

  const generateCaption = useCallback(async (topic) => {
    setLoading(true);
    try {
      return `Hook: ${topic}\nValue: ...\nCTA: Follow for more!`;
    } finally {
      setLoading(false);
    }
  }, []);

  const generateHashtags = useCallback(async (keywords) => {
    setLoading(true);
    try {
      return "#design #frontend #react #coding";
    } finally {
      setLoading(false);
    }
  }, []);

  return { loading, generateCaption, generateHashtags };
}
export default useAI;
