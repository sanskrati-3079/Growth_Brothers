import { useCallback, useState } from "react";

export function useUploader() {
  const [progress, setProgress] = useState(0);
  const [status, setStatus] = useState("idle");

  const upload = useCallback(async (file) => {
    setStatus("uploading");
    for (let p = 10; p <= 100; p += 10) {
      await new Promise((r) => setTimeout(r, 120));
      setProgress(p);
    }
    setStatus("done");
    return { ok: true, id: crypto.randomUUID() };
  }, []);

  return { progress, status, upload };
}
export default useUploader;
